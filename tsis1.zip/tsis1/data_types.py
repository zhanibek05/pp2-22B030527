x = 5
print(type(x))#outp: "int"
