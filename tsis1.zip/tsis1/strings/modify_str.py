#upper case
a = "Hello, World!"
print(a.upper())#HELLO, WORLD!\

#lower case
a = "Hello, World!"
print(a.lower())#hello, world!

#Remove Whitespace
a = " Hello, World! "
print(a.strip()) # returns "Hello, World!" 

#Replace String
a = "Hello, World!"
print(a.replace("H", "J"))#Jello, World!

#Split String
a = "Hello, World!"
print(a.split(",")) # returns ['Hello', ' World!'] 