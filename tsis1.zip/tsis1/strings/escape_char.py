txt = "We are the so-called "Vikings" from the north."#ERROR

#instead
txt = "We are the so-called \"Vikings\" from the north."

