#spaces
if 5 > 2:
    print("Five is greater than two!")
if 5 > 2:
 print("Five is greater than two!") 

#variables
x = 5
y = "Hello, world"

#comments
#this is a comment
