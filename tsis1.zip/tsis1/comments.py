#This is a comment
print("Hello, World!")

print("Hello, World!") #This is a comment

#This is a comment
#written in
#more than just one line
print("Hello, World!")

"""
This is a comment
written in
more than just one line
"""
print("Hello, World!")