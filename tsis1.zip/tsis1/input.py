username = input("Enter username:")
print("Username is: " + username)
