#method copy()
thislist = ["apple", "banana", "cherry"]
mylist = thislist.copy()
print(mylist)

#list()
thislist = ["apple", "banana", "cherry"]
mylist = list(thislist)
print(mylist)


