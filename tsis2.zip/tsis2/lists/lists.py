#creating a List
this_list = ["apple", "banana", "cherry"]
print(this_list)

#List items are ordered, changeable, and allow duplicate values.
#list items are indexed

print(len(this_list))#3 (amount of elements in list)


#list items can be of any data type
list1 = ["apple", "banana", "cherry"]
list2 = [1, 5, 7, 9, 3]
list3 = [True, False, False]

#A list can contain different data types
list4 = ["abc", 34, True, 40, "male"]

#list's data type
print(type(list1))# "<class 'list'>"

#The list() constructor
thelist = list(("bill, will, chill"))#double brackets




