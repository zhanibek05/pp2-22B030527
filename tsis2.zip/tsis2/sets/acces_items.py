#with loop
thisset = {"apple", "banana", "cherry"}

for x in thisset:
    print(x) 

#check items
thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)