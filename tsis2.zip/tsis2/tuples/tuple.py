mytuple = ("apple", "banana", "cherry")
#Tuple items are ordered, unchangeable, and allow duplicate values and items are indexed.

#len
print(len(mytuple))# 3

#one item tuple(remember the comma)
thistuple = ("apple",)
print(type(thistuple))# class 'tuple'

#tuple items - data types
#Tuple items can be of any data type
#A tuple can contain different data types:


#the 'tuple()' constructor
thistuple = tuple(("apple", "banana", "cherry"))#note the double brackets

''' python collections:
-List, Tuple, Set, Dictionary'''