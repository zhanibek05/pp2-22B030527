#Python does not have built-in support for Arrays, but Python Lists can be used instead.
#create an array
cars = ["Ford", "Volvo", "BMW"]
#: This page shows you how to use LISTS as ARRAYS, however, to work with arrays in Python you will have to import a library, like the NumPy library.
#all methods same list methods